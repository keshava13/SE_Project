package com.example.railway.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.railway.model.User;
import com.example.railway.service.LoginService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class LoginController {

	@Autowired
	private LoginService loginService;
	
	@PostMapping("/authenticate")
	public int login(@RequestBody User user) throws Exception {
		System.out.println("im in controller");
		int result;
		result=loginService.authenticate(user);
		return result;
	}
	
	@PostMapping("/createUser")
	public User createUser(@RequestBody User user) throws Exception {
		//System.out.println("im in controller");
		User result;
		result=loginService.createUser(user);
		return result;
	}
	
	@PostMapping("/getUser")
	public User getUserDetails(@RequestBody User user) {
		User getUser=new User();
		getUser=loginService.getUser(user);
		return getUser;
	}
	
}
