import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'app/login-component/login-service';
import { NotificationService } from 'app/notification-service';

@Component({
  selector: 'app-home-component',
  templateUrl: './home-component.component.html',
  styleUrls: ['./home-component.component.css']
})
export class HomeComponentComponent {
  constructor(private http: HttpClient, private loginService: LoginService, private router: Router,
    private notificationService:NotificationService) { }
username:any='';
  ngOnInit(): void {
    this.username=localStorage.getItem("username")
  }
  logout(){
    this.router.navigate(['']);
    localStorage.clear();

  }
}
