import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'app/login-component/login-service';
import { NotificationService } from 'app/notification-service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  constructor(private http: HttpClient, private loginService: LoginService, private router: Router,
    private notificationService:NotificationService) { }

  username:string='';
  email:string='';
  password:string='';

  onSubmit(){
    this.loginService.createUser(this.username,this.email,this.password).subscribe(data=>{
      
        if (data) {
          this.notificationService.showSuccess('User created successfully!');
          this.username='';
this.email='';
this.password=''
        } else {
          this.notificationService.showError('Failed to create user.');
        } 

      
    });
    
  }
}
