import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { LoginService } from './login-service';
import { Router } from '@angular/router';
import { NotificationService } from 'app/notification-service';

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent {
  constructor(private http: HttpClient, private loginService: LoginService, private router: Router,
    private notificationService:NotificationService) { }
  username: string = '';
  password: string = '';
  errorMessage: string = '';
  userObject:any={};
  userType:string="";
  onSubmit() {
    // Add your login logic here
    // Example: make API call to verify email and password
    console.log(this.username);
    
    if (this.username && this.password) {
      this.loginService.authenticate(this.username, this.password).subscribe(data => {
        if (data == 1) {
          localStorage.setItem("username",this.username);
          this.loginService.getUser(this.username).subscribe(data=>{
            
            this.userObject=data
            this.userType=data.userType
          });
          localStorage.setItem("user",this.userObject)
          localStorage.setItem("userType",this.userType)
          console.log('Login successful');
          this.notificationService.showSuccess('welcome '+ this.username);
          console.log(localStorage.getItem("userType"));
          
          this.router.navigate(['/home']);
        }
        else {
          console.log('Login failed');
        }
      })
      

    }
  }

  onSignUp(){
    this.router.navigate(['/signUp']);
  }
}
