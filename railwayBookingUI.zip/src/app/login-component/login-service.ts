import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  constructor(private http: HttpClient) { }

  authenticate(username:any,password:any) {
    var userObject={
        "username":username,
        "password":password
    }
    // Make HTTP GET request to API
    console.log("in service");
    
    return this.http.post<any>('http://localhost:8080/authenticate',userObject);
  }

  getUser(data: any) {
    console.log(data);
    
    var user={"username":data}
    // Make HTTP POST request to API
    return this.http.post<any>('http://localhost:8080/getUser',user);
  }

  createUser(username:string,email:string,password:string){
var user={
  "username":username,
        "password":password,
        "email":email,
        "userType":"CUSTOMER"
}
return this.http.post<any>('http://localhost:8080/createUser',user)
  }
}
