import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  private notificationElement: HTMLElement;
  
  constructor() {
    // Create the notification element dynamically
    this.notificationElement = document.createElement('div');
    this.notificationElement.style.position = 'fixed';
    this.notificationElement.style.top = '20px';
    this.notificationElement.style.right = '20px';
    this.notificationElement.style.padding = '10px';
    this.notificationElement.style.borderRadius = '4px';
    this.notificationElement.style.zIndex = '9999';
    document.body.appendChild(this.notificationElement);
  }

  showSuccess(message: string) {
    this.showNotification(message, 'green');
  }

  showError(message: string) {
    this.showNotification(message, 'red');
  }

  private showNotification(message: string, color: string) {
    this.notificationElement.innerHTML = message;
    this.notificationElement.style.backgroundColor = color;
    this.notificationElement.style.color = 'white';
    this.notificationElement.style.display = 'block';
    setTimeout(() => {
      this.notificationElement.style.display = 'none';
    }, 3000); // Hide the notification after 3 seconds
  }
}
